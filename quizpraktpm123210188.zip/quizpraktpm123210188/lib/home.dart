import 'package:flutter/material.dart';
import 'package:quizpraktpm123210188/groceries.dart';
import 'package:quizpraktpm123210188/detailpage.dart';

class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("List Menu"),
      ),
      body: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (context,index) {
        final Groceries place = groceryList [index];

        return InkWell(
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => DetailPage(place: place)));
          },
          child: Card(
          child: Row(
            children: [
              Container(
                width: 300,
                height: 300,
                child: Image.network(place.productImageUrls[0]),
              ),
              Text(place.name),
            ],
          ),
          ),
        );

      },
        itemCount : groceryList.length,
      ),
    );
  }
}